var quill = new Quill("#editor-feeds", {
    theme: "snow",
});